package com.cg.capbook.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capbook.pagebeans.UserLoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserLoginStepDefinations {

	private WebDriver driver;
	private UserLoginPage userLoginPage;
	
	@Given("^User is on CapBook login page$")
	public void user_is_on_CapBook_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4200/index/signin");
		userLoginPage = PageFactory.initElements(driver, UserLoginPage.class);
	}

	@When("^User Enters his login credentials correctly$")
	public void user_Enters_his_login_credentials_correctly() throws Throwable {
		userLoginPage.setEmailID("hiteshgoyal@gmail.com");
		userLoginPage.setPassword("hitesh1234");
		userLoginPage.clicksignIn();
	}

	@Then("^User is redirected to his account homepage$")
	public void user_is_redirected_to_his_account_homepage() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="CapBook";
		assertEquals(expectedTitle, actualTitle);
		String expectedMessage = "Rishabh Tandon";
		System.out.println("Message2 is"+expectedMessage);
		String actualMessage = userLoginPage.getNameMessage();	
		System.out.println("Message is"+actualMessage);
		assertEquals(expectedMessage, actualMessage);
	}

	
}
