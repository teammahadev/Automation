package com.cg.capbook.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capbook.pagebeans.UserRegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

	
	
public class UserRegistrationStepDefination {

	private WebDriver driver;
	private UserRegistrationPage userRegistrationPage;
	
	@Given("^User is on CapBook signup page$")
	public void user_is_on_CapBook_signup_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4200/index/signup");
		userRegistrationPage = PageFactory.initElements(driver, UserRegistrationPage.class);
	}

	@When("^User Enters his all data correctly$")
	public void user_Enters_his_all_data_correctly() throws Throwable {
		userRegistrationPage.setFirstName("Hitesh");
		userRegistrationPage.setLastName("Goyal");
		userRegistrationPage.setEmailID("hiteshgoyal@gmail.com");
		userRegistrationPage.setPassword("hitesh1234");
		userRegistrationPage.setConfirmPassword("hitesh1234");
		userRegistrationPage.setDateOfBirth("12/01/1996");
		userRegistrationPage.setAge("22");
		userRegistrationPage.setMobileNo("9874561230");
		userRegistrationPage.clickRadio1();
		userRegistrationPage.setFirstSecurityAnswer("Horse");
		userRegistrationPage.setSecondSecurityAnswer("Pasta");
		userRegistrationPage.clickSignUp();
	}

	@Then("^User gets registered and successfull message is displayed\\.$")
	public void user_gets_registered_and_successfull_message_is_displayed() throws Throwable {
		String actualMessage = userRegistrationPage.getMessage();
		String expectedMessage = "Registration Successful!!";		
		
		System.out.println("Message is"+actualMessage);
		System.out.println("Message2 is"+expectedMessage);
		assertEquals(expectedMessage, actualMessage);
	}

	@When("^User enters emailId which already exists$")
	public void user_enters_emailId_which_already_exists() throws Throwable {
		userRegistrationPage.setFirstName("Hitesh");
		userRegistrationPage.setLastName("Goyal");
		userRegistrationPage.setEmailID("hiteshgoyal@gmail.com");
	}

	@Then("^User gets message Email Account already exists!$")
	public void user_gets_message_Email_Account_already_exists() throws Throwable {
	String actualMessage = userRegistrationPage.getEmailErrorMessage();
	String expectedMessage = "Email Account already exists!";
	assertEquals(expectedMessage, actualMessage);
	}
	
	@When("^User enters his all data but password and confirmPassword doesnot match$")
	public void user_enters_his_all_data_but_password_and_confirmPassword_doesnot_match() throws Throwable {
		userRegistrationPage.setFirstName("Hitesh");
		userRegistrationPage.setLastName("Goyal");
		userRegistrationPage.setEmailID("hiteshgoyal5@gmail.com");
		userRegistrationPage.setPassword("hitesh1234");
		userRegistrationPage.setConfirmPassword("hitesh12345");
		userRegistrationPage.setDateOfBirth("12/01/1996");
		userRegistrationPage.setAge("22");
		userRegistrationPage.setMobileNo("9874561230");
		userRegistrationPage.clickRadio1();
		userRegistrationPage.setFirstSecurityAnswer("Horse");
		userRegistrationPage.setSecondSecurityAnswer("Pasta");
		userRegistrationPage.clickSignUp();
	}

	@Then("^User gets message Password/Confirm Password donot match!$")
	public void user_gets_message_Password_Confirm_Password_donot_match() throws Throwable {
		String actualMessage = userRegistrationPage.getEmailErrorMessage();
		String expectedMessage = "Password/Confirm Password donot match!";
		assertEquals(expectedMessage, actualMessage);
	}
	
	
	
}
