package com.cg.capbook.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class UserLoginPage {

	@FindBy(how = How.ID, id="email")
	private WebElement emailID;
	
	@FindBy(how = How.ID, id="password")
	private WebElement password;
	
	@FindBy(how = How.ID, id="submitButton")
	private WebElement button1;
	
	@FindBy(how = How.XPATH,xpath="/html/body/app-root/div/app-dashboard/app-header/nav/div/div[2]/div/div[4]/div/a/font")
	private WebElement nameMessage;

	public UserLoginPage() {
	}

	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void clicksignIn() {
		button1.click();
	}

	public String getNameMessage() {
		return nameMessage.getText();
	}
	
	
	
}
